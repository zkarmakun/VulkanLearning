#include "Material.h"

void FMaterial::LoadFromFile(std::string FilePath)
{
    
}
