#pragma once
#include <string>

class FPaths
{
public:
    static std::string GetProjectDirectory();
    static std::string GetContentDirectory();
};
