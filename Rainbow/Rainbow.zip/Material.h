#pragma once
#include "Core/MinimalCore.h"
#include <string>

class FMaterial
{
public:
    void LoadFromFile(std::string FilePath);
    
private:
    
};
